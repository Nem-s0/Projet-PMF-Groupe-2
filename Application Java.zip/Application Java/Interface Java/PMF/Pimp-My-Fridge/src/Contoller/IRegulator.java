/**
 * 
 */
package Contoller;

/**
 * @author GROUPE 2
 *
 */
public interface IRegulator {
	
	/**
	 * Ajouter un observateur.
	 */
	public void addListener(IRegulatorListener obs);
	
	/**
	 * Retirer un observateur.
	 */
	public void removeListener(IRegulatorListener obs);
	
	/**
	 * Notifier les observateurs quand une nouvelle temperature de consigne a ete donnee.
	 */
	public void notifyConsigneTemperatureChanged(double tempConsigne);
	
	/**
	 * Notifier les observateurs quand la consigne d'allumage change.
	 */
	public void notifyConsigneAllumageChanged(boolean powerState);
	
	/**
	 * Notifier les observateurs quand l'alerte d'�cart de temp�rature change d'etat.
	 */
	public void notifyAlertTemperatureGap(boolean state);
	
	/**
	 * Modifier la temperature de consigne, en  �C.
	 */
	public void setTempConsigne(float tempConsigne);
	
	/**
	 * Recupere la temperature de consigne, en �C.
	 */
	public float getConsigneTemperature();

	/**
	 * Renvoie TRUE si la consigne d'allumage est activ�e.
	 */
	public boolean isConsigneAllumage();

	/**
	 * Renvoie TRUE si l'alerte d'�cart de temp�rature est activ�e.
	 */
	public boolean isAlertTempGap();

}
