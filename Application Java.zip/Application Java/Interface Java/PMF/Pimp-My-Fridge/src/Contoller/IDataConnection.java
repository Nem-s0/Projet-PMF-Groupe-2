/**
 * 
 */
package Contoller;

import Model.DataRetriever;

/**
 * @author GROUPE 2
 *
 */
public interface IDataConnection {
	
	/**
	 * Ajouter un observateur.
	 */
	public void addListener(IDataConnectionListener obs);
	
	/**
	 * Retirer un observateur.
	 */
	public void removeListener(IDataConnectionListener obs);
	
	/**
	 * Notifier les observateurs qu'une nouvelle donnee a lue.
	 */
	public void notifyListeners(DataRetriever data);
	
	/**
	 * Notifier les observateurs quand l'etat d'allumage du refrigerateur est modifie.
	 */
	public void notifyListeners(boolean powerOn);
	
	/**
	 * Activer ou desactiver l'alimentation electrique du refrig�rateur.
	 */
	public void setPowerEnabled(boolean value);
	
	/**
	 * Renvoie TRUE si l'alimentation �lectrique est activ�e.
	 */
	public boolean isPowerEnabled();

	/**
	 * Temps d'allumage depuis le d�but.
	 */
	public long getPowerUptime();
	

}
