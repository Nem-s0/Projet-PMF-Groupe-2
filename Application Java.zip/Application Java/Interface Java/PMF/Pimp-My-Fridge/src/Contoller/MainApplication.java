/**
 * 
 */
package Contoller;

import View.ArduinoConnection;
import View.FirstWindow;

/**
 * @author GROUPE 2
 *
 */
public class MainApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		FirstWindow frame = new FirstWindow();
		ArduinoConnection arduino = new ArduinoConnection();
	}

}
