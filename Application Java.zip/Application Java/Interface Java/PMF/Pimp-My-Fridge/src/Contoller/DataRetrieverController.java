/**
 * 
 */
package Contoller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.PortUnreachableException;

import Model.ArduinoDataSource;
import Model.ArduinoSerial;
import View.ApplicationFrame;
import View.ArduinoConnection;

/**
 * @author GROUPE 2
 *
 */
public class DataRetrieverController {
	
	//private static String PORT_NAME = "COM8";
	
	// Puissance du refrigerateur en Watt
	public static long PUISSANCE_FRIGO = 60;
		
	// Prix EDF en � au kWh au 21/11/15
	@SuppressWarnings("unused")
	private static final double TARIF_KWH = 0.14040d;
	
	private ArduinoDataSource arduinoData;
	
	private ArduinoSerial arduinoSerial;
	
	private ApplicationFrame application;
	
	private ArduinoConnectionController arduinoConnection;
	
	private ArduinoConnection arduino;

	public DataRetrieverController(ApplicationFrame Application, ArduinoConnection Arduino) {
		super();
		this.setApplication(Application);
		this.setArduinoData(new ArduinoDataSource());
		this.setArduino(Arduino);
		this.setArduinoSerial(this.getArduino().getController().getArduinoSerial());
		this.getArduinoSerial().writeData(this.getApplication().getValue());
		this.start();
		
		this.getApplication().getLabelConsigneTemp().setText(this.getApplication().getValue() + "\u00B0C");
		
		this.getApplication().chart.mark.setValue(Double.parseDouble(getApplication().getValue()));
		// On ajoute la donnee au chart
	    this.getApplication().chart.addData((float)this.getArduinoData().getFridge().getTemperatureIn(), (float)this.getArduinoData().getFridge().getTemperatureOut());
		
		this.ApplicationButtonsControl();
		
		if(this.getArduinoData().getFridge().isDewPossible() == true) {
			this.getApplication().getAlertMessage().setText("Risk Of Condensation");
		}
		
		if(this.getArduinoData().getFridge().isTemperatureGap() == true) {
			this.getApplication().getAlertMessage().setText("Anormally Increasing Temperature");
		}
	}
	
	public void start() {
		this.getArduinoSerial().getchosenPort().addDataListener(this.arduinoData);
		this.getArduinoData().addObserver(this);
		try {
			this.getArduinoSerial().connect();
		} catch (PortUnreachableException e) {
			e.printStackTrace();
		}
		
		System.out.println("=== Ouverture de la connexion sur le port " + this.getArduinoSerial().getchosenPort().getSystemPortName() + " ===");
	}

	public void close() {
		this.getArduinoSerial().getchosenPort().removeDataListener();
		this.getArduinoData().removeObserver(this);
		this.getArduinoSerial().disconnect();
		
		System.out.println("=== Fermeture de la connexion sur le port " + this.getArduinoSerial().getchosenPort().getSystemPortName() + " ===");
	}
	
	public void update() {
		System.out.println(this.getArduinoData().getFridge() + "\n");
		this.getApplication().getLabelHumitidy().setText(this.getArduinoData().getFridge().getHumidity() + "%");
		this.getApplication().getLabelTempInt().setText(this.getArduinoData().getFridge().getTemperatureIn() + "\u00B0C");
		this.getApplication().getLabelTempExt().setText(this.getArduinoData().getFridge().getTemperatureOut() + "\u00B0C");
		this.getArduinoData().getFridge().isDewPossible();
		this.getArduinoData().getFridge().isTemperatureGap();
	}
	
	public void ApplicationButtonsControl() {
		
		this.getApplication().getDisconnect().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				DataRetrieverController.this.close();
				DataRetrieverController.this.application.dispose();
				DataRetrieverController.this.arduino.setVisible(true);
				DataRetrieverController.this.arduino.getComboBox().setEnabled(true);
			}
		});
		
		this.getApplication().getOnbutton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				DataRetrieverController.this.getArduinoSerial().writeData("1");
				DataRetrieverController.this.getArduinoSerial().setPowerEnabled(true);
			}
		});
		
		this.getApplication().getOffbutton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				DataRetrieverController.this.getArduinoSerial().writeData("2");
				DataRetrieverController.this.getArduinoSerial().setPowerEnabled(true);
			}
		});
		
		this.getApplication().getRequiredTemperatureIncrease().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				float requiredtemperature = Float.parseFloat(DataRetrieverController.this.getApplication().getValue()) + 0.5f;
				//DataRetrieverController.this.getArduinoSerial().writeData(requiredtemperature);
				DataRetrieverController.this.getApplication().getLabelConsigneTemp().setText(requiredtemperature + "\u00B0C");
			}
		});
		
		this.getApplication().getRequiredTemperatureDecrease().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				float requiredtemperature = Float.parseFloat(DataRetrieverController.this.getApplication().getValue()) - 0.5f;
				DataRetrieverController.this.getApplication().getLabelConsigneTemp().setText(requiredtemperature + "\u00B0C");
			}
		});
		
	}

	/**
	 * @return the arduinoData
	 */
	public ArduinoDataSource getArduinoData() {
		return arduinoData;
	}

	/**
	 * @return the arduinoSerial
	 */
	public ArduinoSerial getArduinoSerial() {
		return arduinoSerial;
	}

	/**
	 * @return the application
	 */
	public ApplicationFrame getApplication() {
		return application;
	}

	/**
	 * @param arduinoData the arduinoData to set
	 */
	public void setArduinoData(ArduinoDataSource arduinoData) {
		this.arduinoData = arduinoData;
	}

	/**
	 * @param arduinoSerial the arduinoSerial to set
	 */
	public void setArduinoSerial(ArduinoSerial arduinoSerial) {
		this.arduinoSerial = arduinoSerial;
	}

	/**
	 * @param application the application to set
	 */
	public void setApplication(ApplicationFrame application) {
		this.application = application;
	}

	/**
	 * @return the arduinoConnection
	 */
	public ArduinoConnectionController getArduinoConnection() {
		return arduinoConnection;
	}

	/**
	 * @return the arduino
	 */
	public ArduinoConnection getArduino() {
		return arduino;
	}

	/**
	 * @param arduinoConnection the arduinoConnection to set
	 */
	public void setArduinoConnection(ArduinoConnectionController arduinoConnection) {
		this.arduinoConnection = arduinoConnection;
	}

	/**
	 * @param arduino the arduino to set
	 */
	public void setArduino(ArduinoConnection arduino) {
		this.arduino = arduino;
	}

	public void onPowerStatusChanged(boolean powerOn) {
		this.getArduinoData().notifyObservers(powerOn);
	}

}
