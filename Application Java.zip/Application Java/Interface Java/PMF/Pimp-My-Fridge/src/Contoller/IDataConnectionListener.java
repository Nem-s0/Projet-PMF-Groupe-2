/**
 * 
 */
package Contoller;

import Model.DataRetriever;

/**
 * @author GROUPE 2
 *
 */
public interface IDataConnectionListener {
	
	/**
	 * Quand une nouvelle donnee est lue.
	 */
	public void onNewStatementRead(DataRetriever data);

	/**
	 * Quand l'etat d'allumage du refrigerateur a change.
	 */
	public void onPowerStatusChanged(boolean powerOn);

}
